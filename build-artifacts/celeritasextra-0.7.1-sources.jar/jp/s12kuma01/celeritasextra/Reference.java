package jp.s12kuma01.celeritasextra;

public class Reference {
    public static final String MOD_ID = "celeritasextra";
    public static final String MOD_NAME = "Celeritas Extra";
    public static final String VERSION = "0.7.1";

    private Reference() {
    }
}
